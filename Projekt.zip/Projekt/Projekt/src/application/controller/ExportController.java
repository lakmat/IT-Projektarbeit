package application.controller;

import application.functions.convert;
import application.functions.eCSV;
import application.functions.eHTML;
import application.functions.eJSON;
import application.model.Data;
import application.view.*;
import java.awt.*;
import java.io.IOException;
import java.nio.file.*;

/**
 *
 * @author lakonkin matvey
 * @version 1.0
 *
 */

public class ExportController {
    private Data d;
    private export e;
    private url_file u;
    private eHTML exrporturl;
    private String url, path;
    private JSON j;
    private CSV c;
    private eCSV eCSV = new eCSV();
    private  convert convert = new convert();
    private eJSON eJSON;
    private Path pathJson;


    public ExportController(export e, Data d){
        this.e = e;
        this.d = d;
        initContExport();

    }

    public ExportController(url_file u, Data d){
        this.d=d;
        this.u=u;
        initContUrlExport();

    }

    public ExportController(CSV c, Data d){
        this.c=c;
        this.d=d;
        initCSVExport();


    }

    public ExportController(JSON j, Data d){
        this.j=j;
        this.d=d;
        initJSONExport();

    }

    //initialize export
   private void initContExport(){
    e.getHelp().addActionListener(e ->
            getHelp());
    e.getBack().addActionListener(e ->
            back());
    e.getWeiter().addActionListener(e ->
    {
        try {
            weiter();
        } catch (IOException e1) {
            e1.printStackTrace();
        }
    });

   }

   //initialize url export
   private void initContUrlExport(){
        //u.();
        u.getBack().addActionListener(e ->
                backchoice3());

        u.getHelp().addActionListener(e ->
                getHelp());
        //u.getWeiter().addActionListener(e ->
             //   exporttoUrl());




   }

   //initialize Json
   private void initJSONExport(){
        j.getBack().addActionListener(e ->
                backchoice2());
        j.getChoose().addActionListener(e ->
                pathJson= j.chooseJson());
        j.getHelp().addActionListener(e ->
                getHelp());
        j.getWeiter().addActionListener(e ->
        {
            try {
                exporttoJson(pathJson.toString());
            } catch (IOException ex) {
                ex.printStackTrace();
            }
        });

   }

   //initialize CSV Export
   private void initCSVExport(){
        c.getBack().addActionListener(e ->
                backchoice1());
        c.getWeiter().addActionListener(e ->
        {
            try {
                exporttoCsv(pathJson.toString());
            } catch (IOException e1) {
                e1.printStackTrace();
            }
        });
       c.getHelp().addActionListener(e ->
               getHelp());
       c.getChoose().addActionListener(e ->
               pathJson = c.chooseCsv());

   }

    //react to selected option
   private void weiter() throws IOException {
       if(e.getJson().isSelected()){
           exportJSON();
       }else if(e.getCsv().isSelected()){

          exportCSV();

       }else if(e.getWebserver().isSelected()){
           exportUrlFile();
       }else {
           e.setBackground(Color.RED);
           e.getJson().setBackground(Color.RED);
           e.getCsv().setBackground(Color.RED);
           e.getCsv().setBackground(Color.RED);
           e.getHelp().setBackground(Color.ORANGE);
           e.getWebserver().setBackground(Color.red);
       }
       e.dispose();



   }
        //exports to url (not finished yet)
        private void exporttoUrl(){
            try {
                exrporturl.export(u.getURL().getText(), d);
            } catch (IOException e1) {
                e1.printStackTrace();
            }
            u.dispose();
        }
        //exports data to json
        private void exporttoJson(String path) throws IOException {
            eJSON = new eJSON(path, d);
            eJSON.exportJson();

            j.dispose();

        }

        //exports data to csv
        private void exporttoCsv(String string) throws IOException {
            eCSV.exportToCSV(d, string);

        c.dispose();
        }
        //creates diagramme again
   private void back(){
       DrawController draw = new DrawController(new diagramme(convert.convert4DrawEinspeisung(d.getSdat()), convert.convert4DrawVerbrauch(d.getSdat()), convert.convert4DrawZaehler(d.getEsl(), d.getSdat()), convert.convert4DrawZaehlerNeg(d.getEsl(), d.getSdat())), d);
        e.dispose();

   }
   private void backchoice1(){

        ExportController e = new ExportController(new export(), d);
        c.dispose();




   }
   public void backchoice2(){
       ExportController e = new ExportController(new export(), d);
       j.dispose();

   }
   public void backchoice3(){
       ExportController e = new ExportController(new export(), d);
       u.dispose();

    }


    //creates help menu
   private void getHelp(){
        help h =new help();

   }

   //creates new export controller using url as parameter
   private void exportUrlFile(){
        ExportController cont =new ExportController(new url_file(), d);
        e.dispose();


   }
   //creates Json export controller
   private void exportJSON(){
        ExportController cont = new ExportController(new JSON(), d);
        e.dispose();
   }

   //creates CSV export controller
   private void exportCSV(){
        ExportController cont = new ExportController(new CSV(), d);
        e.dispose();
   }
   private ExportController getType(){
        return this;
   }





}
