package application.view;

import javax.swing.*;
import java.awt.*;

/*
 * 	@author 	marlon loretz
 *  @date   	30.9.2019
 *  @Version 	1.0
 */

public class url_file extends JFrame{

// 	Variables

    private JTextField pathField = new JTextField();
    //	private JTextField nameField = new JTextField();
    private JTextField urlField = new JTextField();
    private JTextField csvField = new JTextField();

    private JLabel textFile = new JLabel("Bitte geben Sie den gwuenschten Dateipfad an");
    private JLabel textURL = new JLabel("Bitte geben Sie die gewuenschte URL an");
    private JLabel textCSV = new JLabel("Bitte geben Sie einen Pfad ein");
    private JLabel zPfad = new JLabel("Zielpfad");
    //	private JLabel datName = new JLabel("Dateiname");
    private JLabel url = new JLabel("URL");
    private JLabel csv = new JLabel("CSV");

    private JButton weiter = new JButton("Weiter");
    private JButton help = new JButton("Hilfe");
    private JButton back = new JButton("Zurueck");

    //	constructor
    public url_file() {
        initFile();


    }

    /*
     * 	@name		menuGui()
     * 	@info		This methode is building the gui. Additionally it
     * 				contains Listeners to react if a button is pressed.
     */

    public void initFile() {

        JPanel top = new JPanel();
        top.add(textFile);

        JPanel mid = new JPanel();
        mid.setLayout(new GridLayout(2,2));
        mid.add(zPfad);
        mid.add(pathField);
//		mid.add(datName);
//		mid.add(nameField);

        JPanel bottom = new JPanel();
        bottom.setLayout(new GridLayout(1,3));
        bottom.add(back);
        bottom.add(help);
        bottom.add(weiter);


        getContentPane().add(top, BorderLayout.NORTH);
        getContentPane().add(mid, BorderLayout.CENTER);
        getContentPane().add(bottom, BorderLayout.SOUTH);


//	setting up the UI

        setVisible(true);
        setTitle("Pfadeingabe");
        setResizable(false);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setLocationRelativeTo(null);
        pack();

    }

    public JTextField getPathField() {
        return pathField;
    }

    public JTextField getUrlField() {
        return urlField;
    }

    public JButton getWeiter() {
        return weiter;
    }

    public JButton getHelp() {
        return help;
    }

    public JButton getExit() {
        return back;
    }

    /*
     * 	@name		menuGui()
     * 	@info		This methode is building the gui. Additionally it
     * 				contains Listeners to react if a button is pressed.
     */



    public JButton getBack() {
        return back;
    }

    public JLabel getTextFile() {
        return textFile;
    }
    public JTextField getURL(){
        return urlField;
    }
    public JTextField getCSV(){
        return csvField;
    }

}

