package application.view;

import javax.swing.*;
import javax.swing.filechooser.FileSystemView;
import java.awt.*;
import java.nio.file.Path;
import java.nio.file.Paths;

/*
 * 	@author 	Marlon Loretz, Matvey Lakonkin
 *  @date   	30.9.2019
 *  @Version 	1.0
 */

public class CSV extends JFrame{

// 	Variables

    private JTextField pathField = new JTextField();

    private JLabel textFile = new JLabel("Bitte geben Sie den gewuenschten Dateipfad an");
    private JLabel zPfad = new JLabel("Zielpfad");

    private JButton weiter = new JButton("Weiter");
    private JButton help = new JButton("Hilfe");
    private JButton back = new JButton("Zurueck");
    private Path path;
    private JButton choose = new JButton("Choose a Folder");

    //	constructor
    public CSV() {
        JPanel top = new JPanel();

        JPanel mid = new JPanel();
        mid.setLayout(new GridLayout(1,2));
        mid.add(zPfad);
        mid.add(choose);

        JPanel bottom = new JPanel();
        bottom.setLayout(new GridLayout(1,3));
        bottom.add(back);
        bottom.add(help);
        bottom.add(weiter);


        getContentPane().add(top, BorderLayout.NORTH);
        getContentPane().add(mid, BorderLayout.CENTER);
        getContentPane().add(bottom, BorderLayout.SOUTH);


        //	setting up the UI

        setVisible(true);
        setTitle("CSV Eingabe");
        setResizable(false);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setLocationRelativeTo(null);
        pack();


    }

    /*
     * 	@name		menuGui()
     * 	@info		This methode builds the gui. Additionally it
     * 				contains Listeners to react if a button is pressed.
     */



    public JTextField getPathField() {
        return pathField;
    }


    public JButton getWeiter() {
        return weiter;
    }

    public JButton getHelp() {
        return help;
    }

    public JButton getExit() {
        return back;
    }



    public JButton getBack() {
        return back;
    }

    public JLabel getTextFile() {
        return textFile;
    }

    public JTextField pathField(){
        return pathField;
    }

    public Path chooseCsv() {
        JFileChooser jfc = new JFileChooser(FileSystemView.getFileSystemView().getHomeDirectory());
        jfc.setFileSelectionMode(JFileChooser.DIRECTORIES_ONLY);
        int returnValue = jfc.showSaveDialog(null);

        if (returnValue == JFileChooser.APPROVE_OPTION) {
            if (jfc.getSelectedFile().isDirectory()) {
                path = Paths.get(jfc.getSelectedFile().toString());
            }

        }
        return path;
    }

    public JButton getChoose() {
        return choose;
    }
}
