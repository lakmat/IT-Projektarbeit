package application.view;

import javax.swing.*;
import java.awt.*;


/*
 * 	@author 	marlon loretz, matvey lakonkin
 *  @date   	1.10.2019
 *  @Version 	1.0
 */

public class help extends JFrame{

// 	Variables

    private String text = "Sollten Fragen auftreten, so werden diese hier beantwortet. \n"

            + "----------------------------------------------------------------------------------------------------------------------------------------------------------- \n"
            + "Dateipafdeingabe\n"
            + "\n"
            + "Bitte geben Sie den Ordner an, der zu den .sdat Files fuehrt. \n"
            + "Ausserdem muessen Sie den Pfad, der zum .esl File fuehrt angeben.\n"
            + "Falls Sie nicht wissen, wie man einen Pfad angibt, finden Sie\n"
            + "verschiedene Tutorials auf Google oder Youtube.\n"
            + "Bestaetigen Sie ihre Eingabe indem Sie auf weiter klicken. \n"
            + "----------------------------------------------------------------------------------------------------------------------------------------------------------- \n"
            + "Diagramme\n"
            + "\n"
            + "Hier werden Ihnen die Diagramme angezeigt. Falls Sie diese Exportieren\n"
            + "wollen, finden Sie den dazugehoerigen Knopf in der unteren rechten Ecke.\n"
            + "----------------------------------------------------------------------------------------------------------------------------------------------------------- \n"
            + "Hilfe fuer den Export \n"
            + "\n"
            + "Wenn sie \"JSON\" oder \"CSV\" auswaehlen, wird eine Datei generiert.\n"
            + "Falls sie \"Webserver\" auswaehlen, werden die Daten via http auf einen Server geladen. \n"
            + "----------------------------------------------------------------------------------------------------------------------------------------------------------- \n"
            + "Hilfe fuer die Pfadeingabe im Export \n"
            + "\n"
            + "Wenn Sie sich dafuer entschieden haben, die Daten als neue Datei \n"
            + "gespeichert zu bekommen, muessen Sie nun den gewuenschten Dateipfad und -namen eingeben. \n"
            + "\n"
            + "Sollten Sie sich fuer die Webserevr-Variante entschieden haben, so geben Sie die gewuenschte\n"
            + " URL ein. (Diese Option funktioniert gerade nicht)";

    private JTextArea area = new JTextArea(text);


//	constructor: calls the gui method

    public help() {

        init();

    }


    /*
     * 	@name		menuGui()
     * 	@info		This methode is building the gui. Additionally it
     * 				contains Listeners to react if a button is pressed.
     */
    public void init() {

        area.setEditable(false);

        JPanel mainpanel = new JPanel();
        mainpanel.add(area);

        getContentPane().add(mainpanel, BorderLayout.CENTER);


        //	setting up the UI

        setVisible(true);
        setTitle("Hilfe");
        setResizable(false);
        pack();


    }


}
