package application.view;

import org.jfree.chart.ChartPanel;
import org.jfree.chart.JFreeChart;
import org.jfree.chart.axis.DateAxis;
import org.jfree.chart.axis.NumberAxis;
import org.jfree.chart.plot.XYPlot;
import org.jfree.chart.renderer.xy.XYLineAndShapeRenderer;
import org.jfree.data.xy.XYSeries;
import org.jfree.data.xy.XYSeriesCollection;

import javax.swing.*;
import java.awt.*;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;

/**
 * @author kiran kratz, marlon loretz
 * @version 3.0
 */

public class diagramme extends JFrame{

	private JLabel title = new JLabel("Diagramme");

	private JTextArea dia = new JTextArea("Hier kommen die Diagramme");

	private JButton back = new JButton("Zur�ck");
	private JButton help = new JButton("Hilfe");
	private JButton export = new JButton("Exportieren");

	private Date d = new Date();
	SimpleDateFormat datePattern = new SimpleDateFormat("MMM YY");

	public diagramme(ArrayList<ArrayList<String>> ein, ArrayList<ArrayList<String>> ver, ArrayList<ArrayList<String>> zahl, ArrayList<ArrayList<String>> zahlNeg) {

		diagrammeGui(ein, ver, zahl, zahlNeg);

	}

	public void diagrammeGui(ArrayList<ArrayList<String>> ein, ArrayList<ArrayList<String>> ver, ArrayList<ArrayList<String>> zahl, ArrayList<ArrayList<String>> zahlNeg) {

		JPanel top = new JPanel();
		top.add(title);

		JPanel bottom = new JPanel();
		bottom.setLayout(new GridLayout(1,3));
		bottom.add(back);
		bottom.add(help);
		bottom.add(export);


//Diagramm 1
		XYSeries ser = new XYSeries("Z�hlerstand Verbrauch");
		XYSeries ser3 = new XYSeries("Z�hlerstand Einspeisung");
		for(ArrayList<String> e: zahl) {
			ser.add(Double.parseDouble(e.get(0)), Double.parseDouble(e.get(1)));
		}
		for(ArrayList<String> e: zahlNeg) {
			ser3.add(Double.parseDouble(e.get(0)), Double.parseDouble(e.get(1)));
		}

		XYSeriesCollection dataset1 = new XYSeriesCollection();
		dataset1.addSeries(ser);
		dataset1.addSeries(ser3);

		XYLineAndShapeRenderer dot1 = new XYLineAndShapeRenderer();

		DateAxis xax1 = new DateAxis("Monate");
		NumberAxis yax1 = new NumberAxis("kwh");

		xax1.setDateFormatOverride(datePattern);


		XYPlot plot1 = new XYPlot(dataset1, xax1, yax1, dot1);

		JFreeChart chart1 = new JFreeChart(plot1);

//End of Diagramm 1


//Diagramm 2
		XYSeries ser1 = new XYSeries("Verbrauch");
		for(ArrayList<String> e: ver) {
			ser1.add(Double.parseDouble(e.get(0)), Double.parseDouble(e.get(1)));
		}

		XYSeries ser2 = new XYSeries("Einspeisung");
		for(ArrayList<String> e: ein) {
			ser2.add(Double.parseDouble(e.get(0)), Double.parseDouble(e.get(1)));
		}

		XYSeriesCollection dataset2 = new XYSeriesCollection();
		dataset2.addSeries(ser1);
		dataset2.addSeries(ser2);

		XYLineAndShapeRenderer dot2 = new XYLineAndShapeRenderer();

		DateAxis xax2 = new DateAxis("Monate");
		NumberAxis yax2 = new NumberAxis("kwh");

		xax2.setDateFormatOverride(datePattern);

		XYPlot plot2 = new XYPlot(dataset2, xax2, yax2, dot2);

		JFreeChart chart2 = new JFreeChart(plot2);

//End of Diagramm 2

		ChartPanel chartPanel1 = new ChartPanel(chart1);
		ChartPanel chartPanel2 = new ChartPanel(chart2);


		JPanel p = new JPanel(new GridLayout(2,1));
		p.add(chartPanel1);
		p.add(chartPanel2);

		getContentPane().add(top, BorderLayout.NORTH);
		getContentPane().add(p, BorderLayout.CENTER);
		getContentPane().add(bottom, BorderLayout.SOUTH);

		setSize(800, 1000);
		setVisible(true);
		setTitle("Diagramme");
		setResizable(false);
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setLocationRelativeTo(null);


	}
	public JButton getBack() {
		return back;
	}

	public JButton getHelp() {
		return help;
	}

	public JButton getExport() {
		return export;
	}

}
