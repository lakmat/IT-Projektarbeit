package application.view;

import javax.swing.*;
import java.awt.*;

/*
 * 	@author 	marlon loretz
 *  @date   	1.10.2019
 *  @Version 	1.0
 */

public class export extends JFrame{

//	Variables

	private JLabel text = new JLabel("W�hlen Sie bitte Ihren Export aus");
	JPanel mid = new JPanel();


	private JRadioButton json = new JRadioButton("JSON");
	private JRadioButton csv = new JRadioButton("CSV");
	private JRadioButton webserver = new JRadioButton("WebServer");

	private JButton weiter = new JButton("Weiter");
	private JButton help = new JButton("Hilfe");
	private JButton back = new JButton("Zur�ck");

	private ButtonGroup group = new ButtonGroup();

	//	Constructor
	public export() {

		exportGui();

	}

	public void exportGui() {

		JPanel top = new JPanel();
		top.add(text);

		group.add(json);
		group.add(csv);
		group.add(webserver);

		mid.add(json);
		mid.add(csv);
		mid.add(webserver);

		JPanel bottom = new JPanel();
		bottom.setLayout(new GridLayout(1,3));
		bottom.add(back);
		bottom.add(help);
		bottom.add(weiter);


		getContentPane().add(top, BorderLayout.NORTH);
		getContentPane().add(mid, BorderLayout.CENTER);
		getContentPane().add(bottom, BorderLayout.SOUTH);


		setSize(400, 120);
		setVisible(true);
		setTitle("Export");
		setResizable(false);
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setLocationRelativeTo(null);





	}

	public JRadioButton getJson() {
		return json;
	}

	public JRadioButton getCsv() {
		return csv;
	}

	public JRadioButton getWebserver() {
		return webserver;
	}

	public JButton getWeiter() {
		return weiter;
	}

	public JButton getHelp() {
		return help;
	}

	public JButton getBack() {
		return back;
	}
	public JPanel getPanel(){
		return mid;
	}


}
