package application.view;

import javax.swing.*;
import javax.swing.filechooser.FileSystemView;
import java.awt.*;
import java.nio.file.Path;
import java.nio.file.Paths;

/*
 * 	@author 	marlon loretz
 *  @date   	30.9.2019
 *  @Version 	1.0
 */

public class JSON extends JFrame{

// 	Variables


    //	private JTextField nameField = new JTextField();
    private JTextField JSONpfad = new JTextField();

    private JLabel textFile = new JLabel("Bitte geben Sie den gwuenschten Dateipfad an");
    private JLabel textCSV = new JLabel("Bitte geben Sie einen Pfad ein");
    private JButton weiter = new JButton("Weiter");
    private JButton help = new JButton("Hilfe");
    private JButton back = new JButton("Zurueck");
    private JButton choose = new JButton("Choose JSON Pfad");
    private Path path;


    //	constructor
    public JSON() {
        JPanel top = new JPanel();

        JPanel mid = new JPanel();
        mid.setLayout(new GridLayout(1,2));
        mid.add(textCSV);
       // mid.add(JSONpfad);
        mid.add(choose);

        JPanel bottom = new JPanel();
        bottom.setLayout(new GridLayout(1,3));
        bottom.add(back);
        bottom.add(help);
        bottom.add(weiter);


        getContentPane().add(top, BorderLayout.NORTH);
        getContentPane().add(mid, BorderLayout.CENTER);
        getContentPane().add(bottom, BorderLayout.SOUTH);


        //	setting up the UI

        setVisible(true);
        setTitle("JSON  Eingabe");
        setResizable(false);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setLocationRelativeTo(null);
        pack();


    }

    /*
     * 	@name		menuGui()
     * 	@info		This methode is building the gui. Additionally it
     * 				contains Listeners to react if a button is pressed.
     */



    public JTextField getPathField() {
        return JSONpfad;
    }


    public JButton getWeiter() {
        return weiter;
    }

    public JButton getHelp() {
        return help;
    }


    public JButton getBack() {
        return back;
    }

    public JButton getChoose() {
        return choose;
    }

    public JLabel getTextFile() {
        return textFile;
    }

    public Path chooseJson() {
        JFileChooser jfc = new JFileChooser(FileSystemView.getFileSystemView().getHomeDirectory());
        jfc.setFileSelectionMode(JFileChooser.DIRECTORIES_ONLY);
        int returnValue = jfc.showSaveDialog(null);

        if (returnValue == JFileChooser.APPROVE_OPTION) {
            if (jfc.getSelectedFile().isDirectory()) {
                path = Paths.get(jfc.getSelectedFile().toString());
            }

        }
        return path;
    }


}
