package application.view;

import javax.swing.*;
import javax.swing.filechooser.FileSystemView;
import java.awt.*;
import java.nio.file.Path;
import java.nio.file.Paths;

/*
 * 	@author 	marlon loretz, matvey lakonkin
 *  @date   	30.9.2019
 *  @Version 	2.0
 */

public class menu extends JFrame {

// 	Variables

    private JTextField sdatField = new JTextField();
    private JButton choosesdat = new JButton("Choose SDAT Folder");
    private JButton chooseesl = new JButton("Choose ESL");

    private JLabel text = new JLabel("Bitte geben Sie die folgende Sachen ein");
    private JLabel sdat = new JLabel("Ordnerpfad f�r 'SDAT' files");
    private JLabel esl = new JLabel("Dateipfad f�r den 'ESL' file");

    private JButton weiter = new JButton("Weiter");
    private JButton help = new JButton("Hilfe");
    private JButton exit = new JButton("Schliessen");
    private Path path;


    //	Constructor
    public menu() {

        menuGui();

    }

    /*
     * 	@name		menuGui()
     * 	@author		Marlon Loretz
     * 	@date		30.9.2019
     * 	@info		This methode is building the gui. Additionally it
     * 				contains Listeners to react if a button is pressed.
     */
    public void menuGui() {

        JPanel top = new JPanel();
        top.add(text);

        JPanel mid = new JPanel();
        mid.setLayout(new GridLayout(2, 2));
        mid.add(sdat);
        mid.add(choosesdat);
        mid.add(esl);
        mid.add(chooseesl);

        JPanel bottom = new JPanel();
        bottom.setLayout(new GridLayout(1, 3));
        bottom.add(exit);
        bottom.add(help);
        bottom.add(weiter);


        getContentPane().add(top, BorderLayout.NORTH);
        getContentPane().add(mid, BorderLayout.CENTER);
        getContentPane().add(bottom, BorderLayout.SOUTH);


//	setting up the UI
        setSize(400, 150);
        setVisible(true);
        setTitle("Pfadeingabe");
        setResizable(false);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setLocationRelativeTo(null);


    }

    public JButton getWeiter() {
        return weiter;
    }

    public JButton getHelp() {
        return help;
    }

    public JButton getExit() {
        return exit;
    }

    public JTextField getSdatField() {
        return sdatField;
    }

    public JButton getChoosesdat() {
        return choosesdat;
    }

    public JButton getChooseesl() {
        return chooseesl;
    }

    public Path chooseesl() {
        JFileChooser jfc = new JFileChooser(FileSystemView.getFileSystemView().getHomeDirectory());
        jfc.setFileSelectionMode(JFileChooser.FILES_ONLY);
        int returnValue = jfc.showSaveDialog(null);

        if (returnValue == JFileChooser.APPROVE_OPTION) {
            if (jfc.getSelectedFile().isFile()) {
                path = Paths.get(jfc.getSelectedFile().toString());
            }
        }
        return path;
    }

    public Path choosesdat() {
        JFileChooser jfc = new JFileChooser(FileSystemView.getFileSystemView().getHomeDirectory());
        jfc.setFileSelectionMode(JFileChooser.DIRECTORIES_ONLY);
        int returnValue = jfc.showSaveDialog(null);

        if (returnValue == JFileChooser.APPROVE_OPTION) {
            if (jfc.getSelectedFile().isDirectory()) {
                path = Paths.get(jfc.getSelectedFile().toString());
            }

        }
        return path;
    }
}
