package application.functions;

import java.io.File;
import java.util.ArrayList;

public class export {
    private String path, name;
    private ArrayList<ArrayList<String>> data;

    public String getPath(){
        return path;
    }
    public void setPath(String path){
        this.path=path;
    }


    public String getName(){
        return name;
    }
    public void setName(String name){
        this.name = name;
    }

    public ArrayList<ArrayList<String>> getData() {
        return data;
    }


    public void setData(ArrayList<ArrayList<String>> data){
        this.data=data;
    }




    boolean validatePath(String path){
        File file = new File("path");
        if(file.isDirectory()){
            return true;
        }
        else{
            return false;
        }
    }




}
