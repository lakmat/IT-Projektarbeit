package application.functions;

import application.model.PowerData;
import org.w3c.dom.*;
import org.xml.sax.SAXException;

import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;
import javax.xml.parsers.ParserConfigurationException;
import java.io.File;
import java.io.IOException;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.TreeMap;

/**
 * @author kiran kratz, matvey lakonkin
 * @version 2.0
 */
public class rESL {

    File file;								//initialize variables to work with
    TreeMap esl_data;
    DocumentBuilderFactory factory;
    DocumentBuilder builder;
    Document doc;
    Node rootNode;
    NodeList nodes;
    NamedNodeMap attributes;
    double tempEinspeisung;
    double tempVerbrauch;
    Date a;
    SimpleDateFormat datePattern;


    public rESL() {
        datePattern = new SimpleDateFormat("yyyy-MM-dd'T'HH:mm:ss");		//setting values needed
        esl_data = new TreeMap<Long, PowerData>();
    }

    public TreeMap readOne(String path) throws IOException, ParserConfigurationException, SAXException, ParseException {     //method to read one ESL File and return it as TreeMap
        try {
            file = new File(path);
            if(file.exists()) {

                //Initializing variables that we need

                factory = DocumentBuilderFactory.newInstance();
                builder = factory.newDocumentBuilder();
                doc = builder.parse(file);

                rootNode = doc.getDocumentElement();


                //getting started on that selection and reading process

                for(int c = 1; c < rootNode.getChildNodes().item(3).getChildNodes().getLength(); c+=2) {
                    if(rootNode.getChildNodes().item(3).getChildNodes().item(c).getNodeName().compareTo("TimePeriod") == 0){
                        a = datePattern.parse(rootNode.getChildNodes().item(3).getChildNodes().item(c).getAttributes().getNamedItem("end").getNodeValue());
                    }
                    tempEinspeisung = 0;
                    tempVerbrauch = 0;
                    nodes = rootNode.getChildNodes().item(3).getChildNodes().item(c).getChildNodes();
                    for (int z = 1; z < nodes.getLength(); z+=2) {
                        if(nodes.item(z).getAttributes().getNamedItem("obis").getNodeValue().compareTo("1-1:1.8.1") == 0 || nodes.item(z).getAttributes().getNamedItem("obis").getNodeValue().compareTo("1-1:1.8.2") == 0) {
                            tempVerbrauch = tempVerbrauch + Double.parseDouble(nodes.item(z).getAttributes().getNamedItem("value").getNodeValue());
                        }
                        if(nodes.item(z).getAttributes().getNamedItem("obis").getNodeValue().compareTo("1-1:2.8.1") == 0 || nodes.item(z).getAttributes().getNamedItem("obis").getNodeValue().compareTo("1-1:2.8.2") == 0) {
                            tempEinspeisung = tempEinspeisung + Double.parseDouble(nodes.item(z).getAttributes().getNamedItem("value").getNodeValue());
                        }
                    }
                    esl_data.put(a.getTime(), new PowerData(tempEinspeisung, tempVerbrauch, a.getTime()));
                }
            }
        } catch (DOMException e) {
            // TODO Auto-generated catch block
            e.printStackTrace();
        }
        return esl_data;
    }
}