package application.functions;

import application.model.Data;
import application.model.PowerData;

import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Map.Entry;
import java.util.TreeMap;

/**
 * @author kiran kratz, matvey lakonkin
 * @version 1.5
 */
public class convert {

    double mathVar = 0;							//initialization of Variables
    int cnt = 0;
    long nong = 0;
    int indexCNT = 0;
    long date;
    SimpleDateFormat datePattern;
    Calendar cal = Calendar.getInstance();
    ArrayList<String> outVer;
    ArrayList<ArrayList<String>> outList;
    private Data data;

    public convert() {
        datePattern = new SimpleDateFormat("MMM YY");
        outVer = new ArrayList<String>();
        outList = new ArrayList<ArrayList<String>>();
    }

    public ArrayList<ArrayList<String>> convert4DrawVerbrauch(TreeMap<Long, PowerData> sdat) { //converts data to needed date for drawing Verbrauch
        mathVar = 0;
        cnt = 0;
        indexCNT = 0;
        outList = new ArrayList<ArrayList<String>>();
        for(Entry<Long, PowerData> e : sdat.entrySet()) {
            if(cnt < 2879) {
                mathVar = mathVar + e.getValue().getrelativeValVer();
                nong += e.getValue().getDate();
                cnt ++;
            }
            else {
                outVer.add(Double.toString(mathVar));
                date = (nong / 2880);
                outList.add(new ArrayList<String>());
                outList.get(indexCNT).add(""+date);
                outList.get(indexCNT).add(Double.toString(mathVar));
                indexCNT++;
                mathVar = 0;
                cnt = 0;
                nong = 0;
            }
        }
        return outList;
    }
    public ArrayList<ArrayList<String>> convert4DrawEinspeisung(TreeMap<Long, PowerData> sdat) { //converts data to needed date for drawing Einspeisung
        mathVar = 0;
        mathVar = 0;
        cnt = 0;
        indexCNT = 0;
        outList = new ArrayList<ArrayList<String>>();
        for(Entry<Long, PowerData> e : sdat.entrySet()) {
            if(cnt < 2879) {
                mathVar = mathVar + e.getValue().getrelativeValEsp();
                nong+= e.getValue().getDate();
                cnt ++;
            }
            else {
                outVer.add(Double.toString(mathVar));
                date = (nong / 2880);
                outList.add(new ArrayList<String>());
                outList.get(indexCNT).add(""+date);
                outList.get(indexCNT).add(Double.toString(mathVar));
                indexCNT++;
                mathVar = 0;
                cnt = 0;
                nong = 0;
            }
        }
        return outList;
    }
    public ArrayList<ArrayList<String>> convert4DrawZaehler(TreeMap<Long, PowerData> esl, TreeMap<Long, PowerData> sdat1) { //converts data to needed date for drawing Verbrauch Z�hler insgesamt
        mathVar = 0;
        mathVar = 0;
        cnt = 0;
        indexCNT = 0;
        long shared = 0;
        ArrayList<Long> dates = new ArrayList<Long>();
        TreeMap<Long, PowerData> sdat = sdat1;
        for(Entry<Long, PowerData> e : sdat.entrySet()) {
            dates.add(e.getKey());
        }
        shared = getClosest(dates, esl.firstKey());
        for(Entry<Long, PowerData> e : sdat.entrySet()) {
            if(e.getKey() == shared){
                e.getValue().setabsoluteValVer(esl.get(esl.firstKey()).getabsoluteValVer());
                mathVar = esl.get(esl.firstKey()).getabsoluteValVer();
            }
            if(e.getKey() > shared) {
                mathVar = mathVar + e.getValue().getrelativeValVer();
                e.getValue().setabsoluteValVer(mathVar);
            }
        }
        mathVar = 0;
        dates = new ArrayList<Long>();
        for(Entry<Long, PowerData> e : sdat.entrySet()) {
            if(e.getKey() < shared) {
                dates.add(e.getKey());
            }
        }
        mathVar = sdat.get(shared).getabsoluteValVer();
        for(int x=1; x < dates.size(); x++) {
            mathVar -= sdat.get(dates.get(dates.size()-x)).getrelativeValVer();
            if(mathVar >= 0) {
                sdat.get(dates.get(dates.size()-x)).setabsoluteValVer(mathVar);
            }
            else {
                sdat.get(dates.get(dates.size()-x)).setabsoluteValVer(0);
            }
        }
        mathVar = 0;
        cnt = 0;
        indexCNT = 0;
        nong = 0;
        outList = new ArrayList<ArrayList<String>>();
        for(Entry<Long, PowerData> e : sdat.entrySet()) {
            if(cnt < 2879) {
                mathVar = mathVar + e.getValue().getabsoluteValVer();
                nong+= e.getValue().getDate();
                cnt ++;
            }
            else {
                outVer.add(Double.toString(mathVar));
                date = (nong / 2880);
                outList.add(new ArrayList<String>());
                outList.get(indexCNT).add(""+date);
                outList.get(indexCNT).add(Double.toString(mathVar / 2880));
                indexCNT++;
                mathVar = 0;
                cnt = 0;
                nong = 0;
            }
        }
        return outList;
    }
    
    public ArrayList<ArrayList<String>> convert4DrawZaehlerNeg(TreeMap<Long, PowerData> esl, TreeMap<Long, PowerData> sdat1) { //converts data to needed date for drawing Einspeisung Z�hler insgesamt
        mathVar = 0;
        cnt = 0;
        indexCNT = 0;
        long shared = 0;
        ArrayList<Long> dates = new ArrayList<Long>();
        TreeMap<Long, PowerData> sdat = sdat1;
        for(Entry<Long, PowerData> e : sdat.entrySet()) {
            dates.add(e.getKey());
        }
        shared = getClosest(dates, esl.firstKey());
        for(Entry<Long, PowerData> e : sdat.entrySet()) {
            if(e.getKey() == shared){
                e.getValue().setabsoluteValEsp(esl.get(esl.firstKey()).getabsoluteValEsp());
                mathVar = esl.get(esl.firstKey()).getabsoluteValEsp();
            }
            if(e.getKey() > shared) {
                mathVar = mathVar + e.getValue().getrelativeValEsp();
                e.getValue().setabsoluteValEsp(mathVar);
            }
        }
        mathVar = 0;
        dates = new ArrayList<Long>();
        for(Entry<Long, PowerData> e : sdat.entrySet()) {
            if(e.getKey() < shared) {
                dates.add(e.getKey());
            }
        }
        mathVar = sdat.get(shared).getabsoluteValEsp();
        for(int x=1; x < dates.size(); x++) {
            mathVar -= sdat.get(dates.get(dates.size()-x)).getrelativeValEsp();
            if(mathVar >= 0) {
                sdat.get(dates.get(dates.size()-x)).setabsoluteValEsp(mathVar);
            }
            else {
                sdat.get(dates.get(dates.size()-x)).setabsoluteValVer(0);
            }
        }
        mathVar = 0;
        cnt = 0;
        indexCNT = 0;
        nong = 0;
        outList = new ArrayList<ArrayList<String>>();
        for(Entry<Long, PowerData> e : sdat.entrySet()) {
            if(cnt < 2879) {
                mathVar = mathVar + e.getValue().getabsoluteValEsp();
                nong+= e.getValue().getDate();
                cnt ++;
            }
            else {
                outVer.add(Double.toString(mathVar));
                date = (nong / 2880);
                outList.add(new ArrayList<String>());
                outList.get(indexCNT).add(""+date);
                outList.get(indexCNT).add(Double.toString(mathVar / 2880));
                indexCNT++;
                mathVar = 0;
                cnt = 0;
                nong = 0;
            }
        }
        return outList;
    }
    
    public long getClosest(ArrayList<Long> sdat, long date) {
        long distance = 0;
        long edistance = 0;
        int idx = 0;
        for(Long e : sdat) {
            edistance = Math.abs(e - date);
            if(edistance < distance) {
                idx = sdat.indexOf(e);
                distance = edistance;
            }
        }

        return sdat.get(idx);
    }
}
