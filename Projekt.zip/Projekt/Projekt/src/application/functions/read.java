package application.functions;

import java.io.File;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.util.ArrayList;
import java.util.List;

/**
 * @author matvey lakonkin
 * @version 1.0
 */
public class read {
    private Path path;
    private File tmpd;
    private int Filecount;
    private List<String> files;


    public read() {
    }


    protected boolean validate_File(Path path){

        tmpd = new File(path.toString());
        if(tmpd.exists()) {
            return true;
        }
        else{
            return false;
        }
    }
    protected boolean validate_Dir(Path path){
        tmpd = new File(path.toString());
        if(tmpd.isDirectory()){
            Filecount= tmpd.list().length;
            return true;

        }
        else{
            return false;
        }

    }

    public int getFilecount(){
        return Filecount;
    }

    public ArrayList<String> readDir(Path path){
        if(validate_Dir(path)== true) {
            ArrayList<String> file_names = new ArrayList<String>();
            final File file = new File(path.toString());
           for(final File fileEntry : file.listFiles() ){
                file_names.add(fileEntry.getName());
           }
            return file_names;
        }
       else{
           return null;
        }

    }




    public Path getPath(){
        return path;
    }

    public void setPath(String path){

        this.path = Paths.get(path);
    }

}
