package application.functions;

import application.model.Data;
import application.model.PowerData;
import com.google.gson.Gson;

import java.io.File;
import java.io.FileWriter;
import java.io.IOException;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.util.ArrayList;
import java.util.Map;

/**
 * @author lakonkin matvey
 * @version 2.0
 */

public class eJSON{
        private Path path, path2;
        private Gson gson = new Gson();
        private String sensorID;
        private ArrayList<Long> timestamp;
        private Data d;

        /**
         *
         * @param path
         * @param data
         * @throws IOException
         */
        public eJSON(String path,  Data data) throws IOException {

                this.path= Paths.get(path);

                this.d=data;
                this.path.normalize();
                this.path2 = this.path;

                exportJson();

        }

        /**
         *

         * @throws IOException
         */
        public void exportJson() throws IOException {
                jsoninit(this.path2);

                new Gson().toJson(d, new FileWriter(this.path.toString()+ "//info.json//"));


        }

        /**
         *
         * @param path
         * @return
         * @throws IOException
         */
        public void jsoninit(Path path) throws IOException {
                File jsonFile= new File(String.valueOf(path)+"//info.json//");

        }





}
