package application.functions;

import application.model.Data;

import java.io.IOException;
import java.io.PrintWriter;
import java.net.URL;
import java.net.URLConnection;

/**
 * @author matvey lakonkin
 * note: this class is not functionable
 */
public class eHTML {

    private String URL;
    final private String[] schemes = {"http"};
    private StringBuilder parameters;
    private PrintWriter wr;
    URLConnection con;





    public void setURL(String URL){
        this.URL=URL;
    }
    public String getURL(){
        return URL;
    }

    public void export(String url, Data data) throws IOException {

        if(validateURL(URL) == true){

            URL url_export = new URL(url);
            con = url_export.openConnection();
            con.setDoOutput(true);
            wr = new PrintWriter(con.getOutputStream(), true);
            parameters = new StringBuilder();
            
            

        }
        else{

        }
    }



    private boolean validateURL(String url){
        if(url.matches("^[a-z]{4}") && url.startsWith("http")){

            return true;
        }
        else{
            return false;
        }
    }




}
