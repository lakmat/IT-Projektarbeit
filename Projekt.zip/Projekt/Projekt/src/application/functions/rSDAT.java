package application.functions;

import application.model.PowerData;
import org.w3c.dom.Document;
import org.w3c.dom.Node;
import org.w3c.dom.NodeList;

import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;
import java.io.File;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Map.Entry;
import java.util.TreeMap;

/**
 * @author kiran kratz, matvey lakonkin
 * @version 2.0
 */
public class rSDAT extends read{

    private DocumentBuilder dBuilder;    						//initialize variables
    Date a;
    SimpleDateFormat datePattern;
    TreeMap<Long, PowerData> sdat_data;

    public rSDAT() {
        datePattern = new SimpleDateFormat("yyyy-MM-dd'T'HH:mm:ss'Z'");			//setting values
        sdat_data = new TreeMap<Long, PowerData>();
        try {
            DocumentBuilderFactory dbFactory = DocumentBuilderFactory.newInstance();
            dBuilder = dbFactory.newDocumentBuilder();
        } catch (Exception e) {
            e.printStackTrace();
        }

    }
    public TreeMap<Long, PowerData> readAllFiles(String path){					//checks if path is directory or file and acts accordingly
        File fxmlFile = new File(path);											//either iterate reafFile method or not
        if(fxmlFile.isDirectory()) {
            for(File f : fxmlFile.listFiles()){
                readFile(f.getPath());
            }
        }
        else {
            readFile(path);
        }
        return sdat_data;
    }



    public void readFile(String path) {						//reads one File and adds lines as values to TreeMaps
        File fxmlFile = new File(path);
        if (fxmlFile.exists() == true) {
            try{
                Document doc = dBuilder.parse(fxmlFile);
                doc.getDocumentElement().normalize();

                NodeList type = doc.getElementsByTagName("rsm:DocumentID");
                NodeList dates = doc.getElementsByTagName("rsm:StartDateTime");
                NodeList nList = doc.getElementsByTagName("rsm:Sequence");
                NodeList vList = doc.getElementsByTagName("rsm:Volume");
                Node volumeNode = vList.item(0);
                Node seqNode = nList.item(0);
                Date date = datePattern.parse(dates.item(0).getTextContent());

                if(type.item(0).getTextContent().contains("ID742") == true) {
                    sdat_data.put(date.getTime(), new PowerData(Double.parseDouble(volumeNode.getTextContent()), date.getTime(), true));
                }
                else if(type.item(0).getTextContent().contains("ID735") == true){
                    sdat_data.put(date.getTime(), new PowerData(Double.parseDouble(volumeNode.getTextContent()), date.getTime(), false));
                }
                for(int i = 1; i< nList.getLength(); i++){
                    volumeNode = vList.item(i);
                    seqNode = nList.item(i);
                    long dateL = date.getTime() + (Long.parseLong(seqNode.getTextContent()) * 900000);

                    if(type.item(0).getTextContent().contains("ID742") == true) {
                        sdat_data.put(dateL, new PowerData(Double.parseDouble(volumeNode.getTextContent()), dateL, true));
                    }
                    else if(type.item(0).getTextContent().contains("ID735") == true) {
                        sdat_data.put(dateL, new PowerData(Double.parseDouble(volumeNode.getTextContent()), dateL, false));
                    }

                }
            } catch(Exception e){
                e.printStackTrace();
            }
        }

    }




    public TreeMap<Long, PowerData> checkForDoubles(TreeMap<Long, PowerData> sdat_data2){
        Long e1 = (sdat_data2.firstKey()) + 90000;
        for(Entry<Long, PowerData> e : sdat_data2.entrySet()){
            if(sdat_data.get(e.getKey()).getDate() == e1){
                sdat_data2.remove(e1);
            }
            e1 = (e.getKey() + 90000);
        }
        return sdat_data2;
    }
    public static void main(){

    }




}


