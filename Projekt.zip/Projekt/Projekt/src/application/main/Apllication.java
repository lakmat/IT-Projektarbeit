package application.main;

import application.controller.ReadController;
import application.model.Data;
import application.view.menu;

/**
 * @author matvey lakonkin
 * @version 1.0
 * @noinspection ALL
 */

//Main class
public class Apllication{


   public static void main(String[] args) {

        ReadController r = new ReadController(new menu(), new Data());

   }


}
