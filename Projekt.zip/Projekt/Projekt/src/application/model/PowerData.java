package application.model;

/**
 *
 * @author kiran kratz, matvey lakonkin
 * @version 2.0
 */
public class PowerData {
    //saving file lines from docs (esl, sdat)
    private double absoluteValEsp;
    private double absoluteValVer;
    private double relativeValEsp;
    private double relativeValVer;
    private long date;

    public PowerData(double value, long date, boolean plus) {
        this.date = date;
        if(plus == true) {
            relativeValVer = value;
            relativeValEsp = 0;
        }
        else {
            relativeValEsp = value;
            relativeValVer = 0;
        }
    }

    public PowerData(double absoluteValEsp, double absoluteValVer, long date) {
        this.absoluteValEsp = absoluteValEsp;
        this.absoluteValVer = absoluteValVer;
        this.date = date;

    }
    public PowerData(double absoluteValEsp, double absoluteValVer, double relativeValEsp, double relativeValVer, long date) {
        this.absoluteValEsp = absoluteValEsp;
        this.absoluteValVer = absoluteValVer;
        this.date = date;
        this.relativeValEsp = relativeValEsp;
        this.relativeValVer = relativeValVer;

    }
    public double getabsoluteValEsp() {
        return absoluteValEsp;
    }
    public double getabsoluteValVer() {
        return absoluteValVer;
    }
    public double getrelativeValEsp() {
        return relativeValEsp;
    }
    public double getrelativeValVer() {
        return relativeValVer;
    }
    public long getDate() {
        return date;
    }
    public void setabsoluteValEsp(double d) {
        this.absoluteValEsp = d;
    }
    public void setabsoluteValVer(double d) {
        this.absoluteValVer = d;
    }
    public void setrelativeValEsp(double d) {
        this.relativeValEsp = d;
    }
    public void setrelativeValVer(double d) {
        this.relativeValVer = d;
    }
    public void setDate(long d) {
        this.date = d;
    }





}