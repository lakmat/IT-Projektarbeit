package application.model;

import java.util.TreeMap;

/**
 * @author lakonkin matvey
 * @version 1.0
 */
public class Data {
    private TreeMap<Long, PowerData> sdat;
    private  TreeMap<Long, PowerData> esl;



    public Data() {
        sdat = new TreeMap<>();
        esl = new TreeMap<>();

    }

    public TreeMap<Long, PowerData> getEsl() {
        return esl;
    }

    public void setEsl(TreeMap<Long, PowerData> esl) {
        this.esl = esl;
    }




    public TreeMap<Long, PowerData> getSdat() {
        return sdat;
    }

    public void setSdat(TreeMap<Long, PowerData> sdat) {
        this.sdat = sdat;
    }


}
