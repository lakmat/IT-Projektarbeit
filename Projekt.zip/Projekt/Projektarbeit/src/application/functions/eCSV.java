package application.functions;

import application.model.Data;
import application.model.PowerData;

import java.io.FileWriter;
import java.io.IOException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Map;

/**
 * @author kiran kratz, matvey lakonkin
 * @version 1.5
 */
public class eCSV {

    private ArrayList<String> head = new ArrayList<String>(); //Headline/Title of the CSV File (column name)
    private Data data = new Data();
    private String s;
    private FileWriter writer;
    private int cnt;
    private String path;
    SimpleDateFormat datePattern;
    Calendar cal = Calendar.getInstance();

    public eCSV() {
    	datePattern = new SimpleDateFormat("yyyy-MM-dd'T'HH:mm:ss");	//setting needed Values beforehand
        head.add("Timestamp");
        head.add("Value");
    }
    public ArrayList<String> getCSV(Data data){							//gets needed data from Data and returns as ArrayList
        ArrayList<String> CSV = new ArrayList<String>();
        for(Map.Entry<Long, PowerData> entry : data.getSdat().entrySet()){
        	cal.setTimeInMillis(entry.getValue().getDate());
            CSV.add(datePattern.format(cal.getTimeInMillis())+", "+Double.toString(entry.getValue().getabsoluteValVer()));
        }
        return CSV;
    }

    public void exportToCSV(Data data, String path) throws IOException { //exports data as CSV
        this.data = data;
        this.path = path;
        ArrayList<String> a = getCSV(data);

        try {
            writer = new FileWriter(path + "\\CSVinfo.csv\\");
            writer.append("Timestamp");
            writer.append(",");
            writer.append("Value");
            writer.append("\n");

            for(int i = 0 ; i<a.size(); i++ ){
                writer.append(String.join(",", a.get(i)));
                writer.append("\n");
            }

                writer.flush();
                writer.close();
        } catch (IOException e1) {
            e1.printStackTrace();
        }
    }
}