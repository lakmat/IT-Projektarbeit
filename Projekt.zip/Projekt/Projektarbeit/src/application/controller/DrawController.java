package application.controller;

import application.model.Data;
import application.view.diagramme;
import application.view.export;
import application.view.help;
import application.view.menu;

/**
 * @author lakonkin matvey
 * @version 1.0
 */
public class DrawController {
    private diagramme d;
    private Data data;
//constructor
    public DrawController(diagramme d, Data data){
        this.d = d;
        this.data=data;
        initCOntroller();
    }

    //initialize
    public void initCOntroller(){
        d.getBack().addActionListener(e ->
                back());
        d.getHelp().addActionListener(e ->
                createhelp());
        d.getExport().addActionListener(e ->
                exp());

    //creates help menu
    }
    public void createhelp(){
        help h = new help();
    }
    public void exp(){
        ExportController cont = new ExportController(new export(), data);
        d.dispose();
    }
    public void back(){
        d.dispose();
        ReadController r = new ReadController(new menu(), data);

    }

}