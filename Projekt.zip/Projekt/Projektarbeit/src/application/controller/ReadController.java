package application.controller;

import application.functions.convert;
import application.functions.rESL;
import application.functions.rSDAT;
import application.model.Data;
import application.model.PowerData;
import application.view.diagramme;
import application.view.help;
import application.view.menu;
import org.xml.sax.SAXException;

import javax.swing.*;
import javax.swing.filechooser.FileSystemView;
import javax.xml.parsers.ParserConfigurationException;
import java.awt.*;
import java.io.IOException;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.text.ParseException;
import java.time.temporal.JulianFields;
import java.util.TreeMap;

/**
 * @author matvey lakonkin
 * @version 1.0
 *
 */
public class ReadController {

    private Path esl, sdat;
    private rSDAT readSDAT;
    private rESL readESL;
    private int ret = 0;
    private Data data;
    private menu v;
    private menu m;
    String path1, path2;
    private convert c = new convert();
    TreeMap<Long, PowerData> sdatfiles;
    TreeMap<Long, PowerData> eslfiles;


    public ReadController(menu m, Data data){

        this.data = data;
        this.m=m;
        readSDAT = new rSDAT();
        readESL = new rESL();



        initController();





    }
    //initialize
    public void initController(){
        m.getHelp().addActionListener(e ->
                createhelp());
        m.getExit().addActionListener(e ->
                exit());
        m.getWeiter().addActionListener(e ->
                weiter());
        m.getChooseesl().addActionListener(e ->
               esl= m.chooseesl());
        m.getChoosesdat().addActionListener(e ->
                sdat= m.choosesdat());


    }
    //creates help menu
    public void createhelp(){
        help h = new help();
    }


    //reacts to selected options
    public void weiter(){


           esl.normalize();
           sdat.normalize();

            TreeMap<Long, PowerData> dat = readSDAT.readAllFiles(sdat.toString());
            data.setSdat(readSDAT.readAllFiles(sdat.toString()));
            try {
                data.setEsl(readESL.readOne(esl.toString()));
            } catch (IOException e) {
                e.printStackTrace();
            } catch (ParserConfigurationException e) {
                e.printStackTrace();
            } catch (SAXException e) {
                e.printStackTrace();
            } catch (ParseException e) {
                e.printStackTrace();
            }


            DrawController draw = new DrawController(new diagramme(c.convert4DrawEinspeisung(data.getSdat()), c.convert4DrawVerbrauch(data.getSdat()), c.convert4DrawZaehler(data.getEsl(), data.getSdat()), c.convert4DrawZaehlerNeg(data.getEsl(), data.getSdat())), data);
            m.dispose();
        }





    public void checkiffilled(){
        if(m.getSdatField().getText().isEmpty()){

        }

    }


    //disposes the container
    public void exit(){
        m.dispose();

    }









}



